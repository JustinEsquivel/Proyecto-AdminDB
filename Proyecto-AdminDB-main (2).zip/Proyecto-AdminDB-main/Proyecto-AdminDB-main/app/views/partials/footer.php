<footer class="mt-5 py-4 bg-light">
  <div class="container text-center">© <?php echo date('Y'); ?> Patitas Conectadas</div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
